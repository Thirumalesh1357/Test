import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message LogPayload(Message message, String logName, boolean logXML = false, boolean forceLog = false) {
    def body       = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties();
    def logEnabled = 'Y'//properties.get("EnableLogging");
    if (body != "" && messageLog != null && (logEnabled == 'Y' || forceLog)) {
        int logIndex = 1; // Initialize the logIndex;
        if (properties.containsKey("LogIndex")) {
            logIndex = properties.get("LogIndex"); // Get the logIndex if it already exists
        }
        String logSeq = String.format("%02d", logIndex); // If we have more than 99 log entries, consider how much logging do you really need
        messageLog.setStringProperty("Logging ${logSeq}", "Printing Payload as Attachment");
        String format = "text/plain";
        if (logXML) format = "text/xml";
        messageLog.addAttachmentAsString("${logSeq}) ${logName}", body, format);
        message.setProperty("LogIndex", ++logIndex); // Increment the log index        
    }
    return message;
}
def Message Mapping_Payload(Message message) {
    return LogPayload(message, "Mapping record");
}
def Message Upsert_Payload(Message message) {
    return LogPayload(message, "Upsert record", true);
}
def Message CE_Payload(Message message) {
    return LogPayload(message, "CE record");
}
def Message Final_Payload(Message message) {
    return LogPayload(message, "Final record");
}
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList
import groovy.xml.*
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.XmlUtil;
import java.lang.String;
import java.text.DecimalFormat
import java.text.SimpleDateFormat;

import groovy.json.JsonSlurper;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import javax.xml.xpath.*;
import javax.xml.parsers.DocumentBuilderFactory;

import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

class CountryLookup{
    
    String code     =   "";
    String nameEn   =   "";
    String nameAr   =   "";
}

class PersonalInfo{
    
    String firstNameEn  =       "";
    String lastNameEn   =       "";
    String englishName  =       "";
    
    String firstName    =       "";
    String lastName     =       "";
    String arabicName   =       "";
    
    String nationality  =       "";
    String emiratesId   =       "";
    
}


class JobInfo{
    String  recordNumber            =   "";
    String  EDate               =   "";
    String  employeeNumber          =   "";
    String  emiratesId              =   "";
    String  firstName               =   "";
    String  lastName                =   "";
    String  arabicName              =   "";
    String  firstNameEn             =   "";
    String  lastNameEn              =   "";
    String  englishName             =   "";
    
    String  designationArabic       =   "";
    String  designationCode         =   "";
    String  designationEnglish      =   "";
    
    String  salutationArabic        =   "";
    String  dateOfBirth             =   "";
    
    String  companyId               =   "";
    String  companyName             =   "";
    String  companyNameEn           =   "";
    String  companyNameAr           =   "";
    
    String  departmentId            =   "";
    String  departmentName          =   "";
    String  departmentNameEn        =   "";
    String  departmentNameAr        =   "";
    
    String organizationUnitId       =   "";
    String organizationUnitName     =   "";
    String organizationUnitNameAr   =   "";
    String organizationUnitNameEn   =   "";
    
    String  costCenterId            =   "";
    String  costCenterName          =   "";
    String  costCenterEn            =   "";
    String  costCenterAr            =   "";
    
    String  joiningDate             =   "";
    String  leavingDate             =   "";
    String  gender                  =   "";
    String  employementType         =   "";
    String  workType                =   "";
    String  privateTelephone        =   "";
    String  privateMobile           =   "";
    String  privateEmail            =   "";
    String  internalTelephone       =   "";
    String  internalMobile          =   "";
    String  internalEmail           =   "";
    String  nationalityArabic       =   "";
    String  gradeArabic             =   "";
    String  gradeEnglish            =   "";
    String  workLocation            =   "";
    String  vehiclePlateNumber      =   "";
    String  vehicleMake             =   "";
    String  vehicleColour           =   "";
    String  vehiclePlateCode        =   "";
    String  vehicleLicenseing       =   "";
    String  empStatus               =   "";
    String  flag                    =   "";
}

def Message Init(Message message) {     
    

    HashMap<String,JobInfo>         mapJobInfo              =   new HashMap<String,HashMap>();
    HashMap<String,CountryLookup>   mapCountryLookup        =   new HashMap<String,HashMap>();
    HashMap<String,PersonalInfo>    mapPersonalInfo         =   new HashMap<String,HashMap>();
   
    message.setProperty("mapJobInfo"                ,mapJobInfo                     );
    message.setProperty("mapCountryLookup"          ,mapCountryLookup               );
    
    return message;
}

def Message cacheCountryLookup(Message message){
    
    def body        =       message.getBody(java.lang.String);
    def xmlBody     =       new XmlSlurper().parseText(body);
    def properties  =       message.getProperties();
    
    HashMap<String,CountryLookup>     mapCountryLookup   =      properties.get("mapCountryLookup");
    
    xmlBody.Country.each { Desh ->
       
       CountryLookup DeshKaNaam = new CountryLookup();
       
       DeshKaNaam.code      =       Desh.code.toString();
       DeshKaNaam.nameEn    =       Desh.externalName_defaultValue.toString();
       DeshKaNaam.nameAr    =       Desh.externalName_ar_SA.toString();
       
        String keyD = Desh.code.toString();
        mapCountryLookup.put(keyD, DeshKaNaam);
       
    }
    
    String separatorChar = ","; 
    StringBuilder sbItems = new StringBuilder();
    
    AppendValue(sbItems, "Country Code "              ,   separatorChar, false, false);
    AppendValue(sbItems, "Country Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Country Name Arabic"              ,   separatorChar, false, true);
    
    mapCountryLookup.each { keyD, DeshKaNaam ->
        AppendValue(sbItems, DeshKaNaam.code              ,   separatorChar, false, false);
        AppendValue(sbItems, DeshKaNaam.nameEn              ,   separatorChar, false, false);
        AppendValue(sbItems, DeshKaNaam.nameAr              ,   separatorChar, false, true);
    }
    
    //message.setProperty("recordNumber",autoInc);
    message.setBody(sbItems);
    return message;
    //return message;
    
}


def Message creatResponse(Message message) {
    
    def body        = message.getBody(java.lang.String);
    def xmlBody     = new XmlSlurper().parseText(body);
    def properties  = message.getProperties();
    
    message = payLoad(message);
    
    HashMap<String,JobInfo>             mapJobInfo          =       properties.get("mapJobInfo");
    HashMap<String,CountryLookup>       mapCountryLookup    =       properties.get("mapCountryLookup");
    int autoInc     =       properties.get("recordNumber").toInteger();
    String countryCode      =       "";
    testUsers   =   ['AdminAS','AdminHB','AdminMerlin','AdminNK','AdminPS','AdminPY','Antoinet','Dileepk','HariS','INS_SYNC','Khizark','LMS_Sync','MubarishG','PercipioAdmin','RitaS','SF_API','SFAPI','adeelr','arvid','INSSYNC','kassem','S0023431188','SAPSupport','SFADMIN','shub_adham','shub_mohit','Tal_Admin','Testuser1','v4admin']
    

    xmlBody.EmpJob.each { emp ->
    
        if(!(emp.userId.text() in testUsers))
        {
            if(emp.endDate.text() == "9999-12-31T00:00:00.000" || emp.eventNav.PicklistOption.externalCode.text() in ['26','7','R','H','SCWK','ECWK'])
            {
                
                JobInfo job = new JobInfo();
    
                job.recordNumber            =   autoInc;
                job.employeeNumber          =   emp.userId.text();
                def SDate                   =   new SimpleDateFormat("yyyy-MM-dd'T'00:00:00").parse(emp.startDate.text()).format("yyyy-MM-dd'T'00:00:00");
                job.EDate                   =   SDate;
                
                job.firstName               =   emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.firstName.text();
                job.lastName                =   emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.lastName.text();
                job.arabicName              =   emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.displayName.text();
                
                job.firstNameEn             =   emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.firstNameAlt1.text();
                job.lastNameEn              =   emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.lastNameAlt1.text();
                job.englishName             =   emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.customString2.text();
                
                emp.employmentNav.EmpEmployment.personNav.PerPerson.nationalIdNav.PerNationalId.each { id ->
                
                    if( id.cardType.text() == "EmiratesID"){
                        
                        job.emiratesId              =   id.nationalId.text();
                    }
                }
                
                emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.salutationNav.PicklistOption.picklistLabels.PicklistLabel.each { Sal ->
    
                        if(Sal.locale.text() == "en_US"){
                                job.salutationArabic = Sal.label.text()
                        }
    
                    }
                
                job.designationArabic       =   emp.positionNav.Position.externalName_ar_SA.text();
                job.designationCode         =   emp.position.text();
                job.designationEnglish      =   emp.positionNav.Position.externalName_en_US.text();
                job.designationArabic       =   job.designationArabic + " " + job.designationEnglish;
                
                //job.dateOfBirth           =   emp.employmentNav.EmpEmployment.personNav.PerPerson.dateOfBirth.text();
                //def DOB                     =   new SimpleDateFormat("yyyy-MM-dd'T'00:00:00.000").parse(emp.employmentNav.EmpEmployment.personNav.PerPerson.dateOfBirth.text()).format("dd/MM/yyyy");
                // def DOB                     =   emp.employmentNav.EmpEmployment.personNav.PerPerson.dateOfBirth.text()
                
                // if(DOB != '')
                // {
                //     DOB                     =   new SimpleDateFormat("yyyy-MM-dd'T'00:00:00.000").parse(DOB).format("dd/MM/yyyy");
                // }
                
                job.dateOfBirth             =   emp.employmentNav.EmpEmployment.personNav.PerPerson.dateOfBirth.text();
                
                job.companyId               =   emp.company.text();
                job.companyNameAr           =   emp.companyNav.FOCompany.name_ar_SA.text();
                job.companyNameEn           =   emp.companyNav.FOCompany.name_en_US.text();
                job.companyName             =   job.companyNameAr + " " + job.companyNameEn;
                
                job.organizationUnitId            =   emp.customString132.text();
                job.organizationUnitNameAr        =   emp.customString132Nav.cust_Section.cust_Name_ar_SA.text();
                job.organizationUnitNameEn        =   emp.customString132Nav.cust_Section.cust_Name_en_US.text();
                job.organizationUnitName          =   job.organizationUnitNameAr + " " + job.organizationUnitNameEn
                
                job.departmentId            =   emp.department.text();
                job.departmentNameAr        =   emp.departmentNav.FODepartment.name_ar_SA.text();
                job.departmentNameEn        =   emp.departmentNav.FODepartment.name_en_US.text();
                job.departmentName          =   job.departmentNameAr + " " + job.departmentNameEn
                
                job.costCenterId            =   emp.costCenter.text()
                job.costCenterAr            =   emp.costCenterNav.FOCostCenter.name_ar_SA.text();
                job.costCenterEn            =   emp.costCenterNav.FOCostCenter.name_en_US.text();
                job.costCenterName          =   job.costCenterAr + " " + job.costCenterEn;
                
                // def joinDate                =   new SimpleDateFormat("yyyy-MM-dd'T'00:00:00").parse(emp.employmentNav.EmpEmployment.startDate.text()).format("yyyy-MM-dd'T'00:00:00");
                // job.joiningDate             =   joinDate;
                
                def joinDate                =   emp.employmentNav.EmpEmployment.startDate.text()
                job.joiningDate             =   joinDate;
                
                //def leaveDate               =   new SimpleDateFormat("yyyy-MM-dd'T'00:00:00.000").parse(emp.employmentNav.EmpEmployment.startDate.text()).format("dd/MM/yyyy");
                job.leavingDate             =   emp.employmentNav.EmpEmployment.endDate.text();
                
                if (job.leavingDate != ''){
                    job.leavingDate     =   new SimpleDateFormat("yyyy-MM-dd'T'00:00:00").parse(job.leavingDate).format("yyyy-MM-dd'T'00:00:00");
                }
                
                //job.gender                  =   emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.gender.text();
                
                job.employementType         =   emp.employmentTypeNav.PicklistOption.localeLabel.text()
                
                job.workType                =   emp.isFulltimeEmployee.text();
                
                if ( job.workType   ==      "false"){
                    job.workType        =       "1";
                }
                else{
                    job.workType        =       "0";
                }
                
                if(emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.gender.text() == "F")
                {
                    job.gender              =   "1" //Female
                }
                else
                {
                    job.gender              =   "0" //Male
                }
               
                emp.employmentNav.EmpEmployment.personNav.PerPerson.phoneNav.PerPhone.each { Phone ->
                    
                    if( Phone.phoneType.text() == "29419"){
                        job.privateTelephone        =   Phone.phoneNumber.text()
                    }
                    
                    if( Phone.phoneType.text() == "29421"){
                        job.privateMobile        =   Phone.phoneNumber.text()
                    }
                    
                    if( Phone.phoneType.text() == "29418"){
                        job.internalTelephone        =   Phone.phoneNumber.text()
                    }
                    
                    if( Phone.phoneType.text() == "41325"){
                        job.internalMobile        =   Phone.phoneNumber.text()
                    }
                    
                }
                
                emp.employmentNav.EmpEmployment.personNav.PerPerson.emailNav.PerEmail.each{ Email ->
                
                    if( Email.emailType.text() == "29411"){
                        job.internalEmail       =   Email.emailAddress.text()
                    }
                    
                    if( Email.emailType.text() == "29413"){
                        job.privateEmail       =   Email.emailAddress.text()
                    }
                }
              
    
                //job.nationalityArabic       =    emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.nationality.text();
                countryCode                 =       emp.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.nationality.text();
                 if(mapCountryLookup.get(countryCode) != null &&  mapCountryLookup.get(countryCode) != ""){
                // if(!mapCountryLookup.get(countryCode))
                    job.nationalityArabic       =      mapCountryLookup.get(countryCode).nameAr; 
                }
                else{
                    job.nationalityArabic       =   "";
                }
                job.gradeArabic             =    emp.payGradeNav.FOPayGrade.nameTranslationNav.FoTranslation.value_ar_SA.text();   
                job.gradeEnglish            =    emp.payGradeNav.FOPayGrade.name.text()
                job.workLocation            =    emp.locationNav.FOLocation.name.text();
                
                job.vehiclePlateNumber      =    emp.userNav.User.UserOfcust_Vehicle_NumberNav.cust_Vehicle_Number.cust_New_Vehicle_Number.cust_Vehicle_Number_Details.cust_Plate_Number.text()
                job.vehicleMake             =    emp.userNav.User.UserOfcust_Vehicle_NumberNav.cust_Vehicle_Number.cust_New_Vehicle_Number.cust_Vehicle_Number_Details.cust_Vehicle_BrandNav.PickListValueV2.label_ar_SA.text();
                job.vehicleColour           =       "";
                job.vehiclePlateCode        =    emp.userNav.User.UserOfcust_Vehicle_NumberNav.cust_Vehicle_Number.cust_New_Vehicle_Number.cust_Vehicle_Number_Details.cust_Plate_CodeNav.PickListValueV2.label_en_US.text()
                job.vehicleLicenseing       =    emp.userNav.User.UserOfcust_Vehicle_NumberNav.cust_Vehicle_Number.cust_New_Vehicle_Number.cust_Vehicle_Number_Details.cust_EmiratesNav.PickListValueV2.label_ar_SA.text()
                
                if(emp.eventNav.PicklistOption.externalCode.text() in ['26','7','ECWK']){
                    job.empStatus               =       "1"
                }
                else{
                    job.empStatus               =       "0";
                }
                // if(emp.eventNav.PicklistOption.externalCode.text() == "H"){
                //   job.flag                     =       "0"; 
                // }
                // else{
                //     job.flag                    =       "1";
                // }
                String key = emp.userId.text() + emp.dateOfBirth.text()
                if(mapJobInfo.containsKey(key)){
                    key = key + "-1"
                }
                mapJobInfo.put(key ,job);
                autoInc +=  1;
            }
        }
        
    }
    
    String separatorChar = ","; 
    StringBuilder sbItems = new StringBuilder();
    
    AppendValue(sbItems, "Record Number "              ,   separatorChar, false, false);
    AppendValue(sbItems, "Employee number"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Designation - Arabic"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Emp. Arabic Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Empl. English Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "English Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Arabic Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Date of Birth"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Company-ID"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Company-Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Department -ID"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Department-Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Cost Center-ID"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Cost Center-Name"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Joining Date"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Leaving Date"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Gender"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Employment Type"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Work tyoe"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Private-Telephone"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Private-Mobile"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Private-Email"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Internal-Telephone"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Internal-Mobile"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Internal-Email"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Nationality"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Grade - Arabic"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Grade - English"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Work Location"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Vehicle Plate Number"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Vehicle make"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Vehicle color"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Vehicle Plate code"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Vehicle licening "              ,   separatorChar, false, false);
    AppendValue(sbItems, "Emp. Status"              ,   separatorChar, false, false);
    AppendValue(sbItems, "Flag"              ,   separatorChar, false, true);
 
    
    mapJobInfo.each { key, job ->
        AppendValue(sbItems, job.recordNumber              ,   separatorChar, false, false);
        AppendValue(sbItems, job.employeeNumber              ,   separatorChar, false, false);
        AppendValue(sbItems, job.firstName              ,   separatorChar, false, false);
        AppendValue(sbItems, job.lastName              ,   separatorChar, false, false);
        AppendValue(sbItems, job.arabicName              ,   separatorChar, false, false);
        AppendValue(sbItems, job.designationArabic              ,   separatorChar, false, false);
        AppendValue(sbItems, job.dateOfBirth              ,   separatorChar, false, false);
        AppendValue(sbItems, job.companyId              ,   separatorChar, false, false);
        AppendValue(sbItems, job.companyName              ,   separatorChar, false, false);
        AppendValue(sbItems, job.departmentId              ,   separatorChar, false, false);
        AppendValue(sbItems, job.departmentName              ,   separatorChar, false, false);
        AppendValue(sbItems, job.costCenterId              ,   separatorChar, false, false);
        AppendValue(sbItems, job.costCenterName              ,   separatorChar, false, false);
        AppendValue(sbItems, job.joiningDate              ,   separatorChar, false, false);
        AppendValue(sbItems, job.leavingDate              ,   separatorChar, false, false);
        AppendValue(sbItems, job.gender              ,   separatorChar, false, false);
        AppendValue(sbItems, job.employementType              ,   separatorChar, false, false);
        AppendValue(sbItems, job.workType              ,   separatorChar, false, false);
        AppendValue(sbItems, job.privateTelephone              ,   separatorChar, false, false);
        AppendValue(sbItems, job.privateMobile              ,   separatorChar, false, false);
        AppendValue(sbItems, job.privateEmail              ,   separatorChar, false, false);
        AppendValue(sbItems, job.internalTelephone              ,   separatorChar, false, false);
        AppendValue(sbItems, job.internalMobile              ,   separatorChar, false, false);
        AppendValue(sbItems, job.internalEmail              ,   separatorChar, false, false);
        AppendValue(sbItems, job.nationalityArabic              ,   separatorChar, false, false);
        AppendValue(sbItems, job.gradeArabic              ,   separatorChar, false, false);
        AppendValue(sbItems, job.gradeEnglish              ,   separatorChar, false, false);
        AppendValue(sbItems, job.workLocation              ,   separatorChar, false, false);
        AppendValue(sbItems, job.vehiclePlateNumber              ,   separatorChar, false, false);
        AppendValue(sbItems, job.vehicleMake              ,   separatorChar, false, false);
        AppendValue(sbItems, job.vehicleColour              ,   separatorChar, false, false);
        AppendValue(sbItems, job.vehiclePlateCode              ,   separatorChar, false, false);
        AppendValue(sbItems, job.vehicleLicenseing              ,   separatorChar, false, false);
        AppendValue(sbItems, job.empStatus              ,   separatorChar, false, false);
        AppendValue(sbItems, job.flag              ,   separatorChar, false, true);

    }
    
    message.setProperty("recordNumber",autoInc);
    message.setBody(sbItems);
    return message;
}


def Message BuildXML (Message message)  {

    //message                 = LogPayload(message, "_CSV Format");
    def properties          = message.getProperties();

    HashMap<String,JobInfo>      mapJobInfo    =     properties.get("mapJobInfo");
   
    empty = ""

    def stringWriter = new StringWriter()
    def builder = new MarkupBuilder(stringWriter)
    builder.cust_EmployeeDataforTime
    {
            mapJobInfo.each { key, Records ->

                cust_EmployeeDataforTime() {

                    effectiveStartDate(Records.EDate.toString());
                    // transactionSequence('1');
					externalCode(Records.employeeNumber);
					cust_RecordNumber(Records.recordNumber);
                    cust_Employeenumber(Records.employeeNumber);
                    cust_EmiratesID(Records.emiratesId);
                    //cust_Title(Records.salutationArabic);
                    //cust_Title(Records.designationArabic);
                    cust_EmpArabicName(Records.firstName + " " + Records.lastName);
                    cust_EmpEnglishName(Records.firstNameEn + " " + Records.lastNameEn);
                    cust_EnglishName(Records.englishName);
                    cust_ArabicName(Records.arabicName);
                    cust_DateofBirth(Records.dateOfBirth);
                    cust_CompanyID(Records.companyId);
                    cust_CompanyName(Records.companyName);
                    cust_DepartmentID(Records.departmentId);
                    cust_DepartmentName(Records.departmentName);
                    cust_OrganizationUnitId(Records.organizationUnitId);
                    cust_OrganizationUnitName(Records.organizationUnitName);
                    cust_DesignationName(Records.designationArabic);
                    //cust_DesignationID(Records.designationCode);
                    //cust_CostCenterID(Records.costCenterId);
                    //cust_CostCenterName(Records.costCenterName);
                    cust_JoiningDate(Records.joiningDate);
                    cust_LeavingDate(Records.leavingDate);
                    cust_Gender(Records.gender);
                    cust_EmploymentType(Records.employementType);
                    cust_Worktype(Records.workType);
                    cust_PrivateTelephone(Records.privateTelephone);
                    cust_PrivateMobile(Records.privateMobile);
                    cust_PrivateEmail(Records.privateEmail);
                    cust_InternalTelephone(Records.internalTelephone);
                    cust_InternalMobile(Records.internalMobile);
                    cust_InternalEmail(Records.internalEmail);
                    cust_Nationality(Records.nationalityArabic);
                    cust_GradeArabic(Records.gradeArabic);
                    cust_GradeEnglish(Records.gradeEnglish);
                    cust_WorkLocation(Records.workLocation);
                    cust_VehiclePlateNumber(Records.vehiclePlateNumber);
                    cust_Vehiclemake(Records.vehicleMake);
                    //cust_Vehiclecolor(Records.vehicleColour);
                    cust_VehiclePlatecode(Records.vehiclePlateCode);
                    cust_VehicleRegistration(Records.vehicleLicenseing);
                    cust_Response("false");
                    cust_EmpStatus(Records.empStatus);
                    //Flag();
                    

                }
            }
    }
    xml1 = stringWriter.toString()    
    message.setBody(xml1);
    return message
}


def void AppendValue(StringBuilder sbItems, String stringToAppend, String separatorChar, boolean wrapInQuotes, boolean endOfLine, StringBuilder sbLogItems = null, boolean sensitiveData = false) {
    if (endOfLine) {
        separatorChar = "\n";       
    }
    
    String logStringToAppend = stringToAppend;
    if (sensitiveData && !stringToAppend.isEmpty()) {
        logStringToAppend = "****"; // Replace sensitive data in log entries
    }
    
    if (!wrapInQuotes) {
        sbItems.append("${stringToAppend}").append(separatorChar);
        
        if (sbLogItems != null) {
            sbLogItems.append("${logStringToAppend}").append(separatorChar);
        }
    } else {
        sbItems.append("\"${stringToAppend}\"").append(separatorChar);
        
        if (sbLogItems != null) {
            sbLogItems.append("\"${logStringToAppend}\"").append(separatorChar);
        }
    }
}


def Message payLoad(Message message) {
    def body = message.getBody(java.lang.String) as String;
    
    def messageLog = messageLogFactory.getMessageLog(message);
    //if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("SF Raw Data:", body, "text/plain");
     //}
    return message;
}
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

Message processData(Message message) {
    def props = message.getProperties()

    def newPayload = props.get("newPayload") ?: ""
    def oldPayload = props.get("oldPayload") ?: ""

    // Validate payloads
    if (!newPayload?.trim() || !oldPayload?.trim()) {
        message.setProperty("continueFlow", true)
        message.setBody("One or both payloads are empty. Ending flow.")
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog?.addAttachmentAsString("Comparison Result", "EMPTY PAYLOAD", "text/plain")
        return message
    }

    // Parse and flatten XMLs
    def newXml = new XmlSlurper().parseText(newPayload)
    def oldXml = new XmlSlurper().parseText(oldPayload)

    def flatten = { xml ->
        def result = [:]
        xml.depthFirst().findAll { it.children().size() == 0 }.each {
            result[it.name().toString()] = it.text().trim()
        }
        return result
    }

    def newMap = flatten(newXml)
    def oldMap = flatten(oldXml)

    // Compare flattened maps
    def isEqual = newMap == oldMap

    def messageLog = messageLogFactory.getMessageLog(message)
    if (isEqual) {
        message.setProperty("continueFlow", false)
        message.setBody("Payload values match. Ending flow.")
        messageLog?.addAttachmentAsString("Comparison Result", "Payloads are equal", "text/plain")
    } else {
        message.setProperty("continueFlow", true)
        message.setBody(newPayload)
        messageLog?.addAttachmentAsString("Comparison Result", "Payloads differ. Sending new payload.", "text/plain")
    }

    return message
}

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String)

    // Store full XML as string in property
    message.setProperty("oldPayload", body)

    return message
}
